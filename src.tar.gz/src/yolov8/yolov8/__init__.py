# /home/guoxuan/lab/yolo_ros/src/yolov8/yolov8/__init__.py
